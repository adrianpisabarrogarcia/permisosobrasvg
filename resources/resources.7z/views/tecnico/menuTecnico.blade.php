<div id="layoutSidenav">
    <div id="layoutSidenav_nav">
        <nav class="sb-sidenav accordion sb-sidenav-dark rounded-top" id="sidenavAccordion">
            <div class="sb-sidenav-menu">
                <div class="nav">
                    <div class="sb-sidenav-menu-heading  bg-dark pt-3">Solicitudes</div>
                    <a class="nav-link" href="portal.blade.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Solicitudes Pendientes
                    </a>
                    <a class="nav-link" href="portal.blade.php">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Comprobar Solicitudes
                    </a>
                    <div class="sb-sidenav-menu-heading bg-dark pt-3">Datos</div>
                    <a class="nav-link " href="#">
                        <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                        Usuarios
                    </a>
                </div>
            </div>
            <div class="sb-sidenav-footer">
                <div class="small">Logged in as:</div>
                {{Session::get("nombre")}}
            </div>
        </nav>
    </div>
</div>
