<div class="sb-sidenav-footer">
    <div class="small">Logged in as:</div>
    suario registrado      {{Session::get("nombre")}}
</div>
